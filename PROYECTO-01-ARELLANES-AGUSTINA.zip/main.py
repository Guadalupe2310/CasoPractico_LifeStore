
''''
Nivel Básico:
Login de usuario-administrador:
● Al ejecutar el programa, solicitar al usuario sus datos de acceso (nombre de
usuario y contraseña) y permitir visualizar el reporte siempre que los datos sean
correctos.
● Definir dentro del código el siguiente usuario que deberá tener permisos de
administrador:
○ nombre de usuario: emtech
○ contraseña: caso1
Productos más vendidos y productos rezagados:
● Generar un listado de los 5 productos con mayores ventas y uno con los 10
productos con mayor búsquedas.
● Por categoría, generar un listado con los 5 productos con menores ventas y
uno con los 10 productos con menores búsquedas.
'''
"""
This is the LifeStore_SalesList data:

lifestore_searches = [id_search, id product]
lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore_products = [id_product, name, price, category, stock]
"""

#Definir usuario Administrador
User='emtech'
password='caso1'

#Capturar usuario y contraseña
print('==========LOGIN==========')
Usertxt=input("Nombre de usuario: ")
Passtxt=input("Contraseña: ")

#importar documento
import lifestore_file


print('\n')

  
if Usertxt==User and Passtxt==password:
  print("=================REPORTES LIFESTORE=================")
  
  print('\n')
  print("------5 productos con mayores ventas------")
  #Variables de las listas auxiliares
  IDList=[]
  NombreLista=[]
  
  #buscar los primeros 5 productos con valor de venta 5
  for i in range(len(lifestore_file.lifestore_sales)):
    if lifestore_file.lifestore_sales[i][2] == 5:
      IDList.append(lifestore_file.lifestore_sales[i][1])
      if len(IDList) == 5:
        break;
  #print(IDList)
  #Buscar el nombre del id almacenado en la tmp IDList en la lista de los productos
  for i in range(len(IDList)):
    for x in range(len(lifestore_file.lifestore_products)): 
      if IDList[i] == lifestore_file.lifestore_products[x][0]:
        NombreLista=(lifestore_file.lifestore_products[x][1])
    print("-Producto "+str(i+1)+": "+ NombreLista)#Imprimir lista
    
  print('\n')
  print("------10 productos con mayores ventas------")   
  #Variables de las listas auxiliares
  IDList10=[]
  NombreLista10=[]
   #buscar los primeros 10 productos con valor de venta 5
  for i in range(len(lifestore_file.lifestore_sales)):
    if lifestore_file.lifestore_sales[i][2] == 5:
      IDList10.append(lifestore_file.lifestore_sales[i][1])
      if len(IDList10) == 10:
        break;
  #print(IDList)
  #Buscar el nombre del id almacenado en la tmp IDList en la lista delos productos
  for i in range(len(IDList10)):
    for x in range(len(lifestore_file.lifestore_products)): 
      if IDList10[i] == lifestore_file.lifestore_products[x][0]:
        NombreLista10=(lifestore_file.lifestore_products[x][1])
    print("-Producto "+str(i+1)+": "+ NombreLista10)#Imprimir lista
    
  print('\n')
  print("------5 productos con menores ventas------")
  #Variables de las listas auxiliares
  IDListmenor=[]
  NombreListamenor=[]
  
  #buscar los primeros 5 productos con valor de venta 1
  for i in range(len(lifestore_file.lifestore_sales)):
    if lifestore_file.lifestore_sales[i][2] == 1:
      IDListmenor.append(lifestore_file.lifestore_sales[i][1])
      if len(IDListmenor) == 5:
        break;
  #print(IDListmenor)
  #print(IDList)
  #Buscar el nombre del id almacenado en la tmp IDList en la lista delos productos
  for i in range(len(IDListmenor)):
    for x in range(len(lifestore_file.lifestore_products)): 
      if IDListmenor[i] == lifestore_file.lifestore_products[x][0]:
        NombreListamenor=(lifestore_file.lifestore_products[x][1])
    print("-Producto "+str(i+1)+": "+ NombreListamenor)#Imprimir lista

  print('\n')
  print("------10 productos con menores busqueda------")
  #Variables de las listas auxiliares
  IDListmenor=[]
  NombreListamenor=[]
  
  
  for i in range(len(lifestore_file.lifestore_searches )):
    if lifestore_file.lifestore_searches [i][1] == 1:
      IDListmenor.append(lifestore_file.lifestore_searches [i][1])
      if len(IDListmenor) == 10:
        break;
  #print(IDListmenor)
  #print(IDList)
  #Buscar el nombre del id almacenado en la tmp IDList en la lista delos productos
  for i in range(len(IDListmenor)):
    for x in range(len(lifestore_file.lifestore_products)): 
      if IDListmenor[i] == lifestore_file.lifestore_products[x][0]:
        NombreListamenor=(lifestore_file.lifestore_products[x][1])
    print("-Producto "+str(i+1)+": "+ NombreListamenor)#Imprimir lista
else:
  print("¡Usuario no permitido!, Intente de nuevo")
